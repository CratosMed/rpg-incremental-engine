class Item:
    def __init__(self, nombre, rareza, valor_base, tipo, stats=None):
        # Propiedades básicas del objeto
        self.nombre = nombre
        self.rareza = rareza  # Ej: "Común", "Mágico", "Raro", "Único"
        self.valor_base = valor_base  # Cuánto oro te dan en la tienda por él
        self.tipo = tipo  # Ej: "Arma", "Armadura", "Material"

        # Las estadísticas serán un diccionario. Si no le pasamos nada, crea uno vacío {}
        self.stats = stats if stats is not None else {}

        # Nivel de mejora en la herrería (empieza en 0)
        self.nivel_mejora = 0

    # El método __str__ le dice a Python cómo mostrar este objeto si usamos print()
    def __str__(self):
        texto = f"[{self.rareza}] {self.nombre}"
        if self.nivel_mejora > 0:
            texto += f" (+{self.nivel_mejora})"

        texto += f" | Tipo: {self.tipo} | Valor: {self.valor_base} oro"

        if self.stats:
            texto += f" | Stats: {self.stats}"

        return texto


class Player:
    def __init__(self, nombre):
        self.nombre = nombre
        self.nivel = 1
        self.oro = 0
        # --- NUEVO: Sistema de Experiencia ---
        self.exp_actual = 0
        self.exp_necesaria = 50  # Cuánta exp necesita para pasar al nivel 2

        # Estadísticas base del personaje desnudo
        self.hp_max = 100
        self.hp_actual = 100
        self.daño_base = 5

        # El inventario es una simple lista donde guardaremos los objetos 'Item'
        self.inventario = []

        # El equipamiento es un diccionario con "ranuras" específicas
        self.equipamiento = {"Arma": None, "Armadura": None}

    def equipar(self, item):
        # Verificamos si la ranura existe (Ej: si el tipo es "Arma", entra aquí)
        if item.tipo in self.equipamiento:
            self.equipamiento[item.tipo] = item
            print(f"> {self.nombre} se ha equipado: {item.nombre}")
        else:
            print(f"> No hay ranura para equipar un objeto de tipo {item.tipo}.")

    def obtener_daño_total(self):
        # Empezamos con el daño natural del personaje
        daño_total = self.daño_base

        # Revisamos si tiene un arma en la mano
        arma_equipada = self.equipamiento["Arma"]

        # Si hay un arma, y esa arma tiene la estadística "daño", se la sumamos
        if arma_equipada is not None and "daño" in arma_equipada.stats:
            daño_total += arma_equipada.stats["daño"]

        return daño_total

    def mostrar_estado(self):
        print(f"\n--- ESTADO DE {self.nombre.upper()} ---")
        print(f"Nivel: {self.nivel} | Oro: {self.oro}")
        print(
            f"HP: {self.hp_actual}/{self.hp_max} | Daño Total: {self.obtener_daño_total()}"
        )

        arma = self.equipamiento["Arma"]
        # Usamos un operador ternario: muestra el nombre si hay arma, si no, dice 'Ninguna'
        print(f"Arma equipada: {arma.nombre if arma else 'Ninguna'}")

    def ganar_exp(self, cantidad):
        self.exp_actual += cantidad
        print(
            f"✨ {self.nombre} gana {cantidad} EXP. ({self.exp_actual}/{self.exp_necesaria})"
        )

        # Comprobamos si tiene suficiente exp para subir de nivel
        if self.exp_actual >= self.exp_necesaria:
            self.subir_nivel()

    def subir_nivel(self):
        self.nivel += 1
        # La experiencia sobrante se guarda para el siguiente nivel
        self.exp_actual -= self.exp_necesaria

        # Aumentamos la exp necesaria para el próximo nivel (Curva exponencial del 50% extra)
        self.exp_necesaria = int(self.exp_necesaria * 1.5)

        # Mejoramos las estadísticas base del personaje
        self.hp_max += 20
        self.hp_actual = self.hp_max  # Le curamos la vida al subir de nivel
        self.daño_base += 2

        print(f"🎉 ¡NUEVO NIVEL! {self.nombre} ha alcanzado el Nivel {self.nivel}!")


class Enemy:
    def __init__(self, nombre, hp, daño, exp_recompensa, oro_recompensa):
        self.nombre = nombre
        self.hp_max = hp
        self.hp_actual = hp
        self.daño = daño

        # Lo que soltará al morir
        self.exp_recompensa = exp_recompensa
        self.oro_recompensa = oro_recompensa

    def recibir_daño(self, cantidad):
        self.hp_actual -= cantidad

        # Evitamos que la vida baje de cero para que la barra no se vea extraña después
        if self.hp_actual < 0:
            self.hp_actual = 0

        print(
            f"💥 ¡Zasca! {self.nombre} recibe {cantidad} puntos de daño. (HP: {self.hp_actual}/{self.hp_max})"
        )

    def esta_vivo(self):
        # Devuelve True si le queda vida, False si ya llegó a 0
        return self.hp_actual > 0


# --- ZONA DE PRUEBAS ---
if __name__ == "__main__":
    # 1. Preparamos el terreno
    espada_rara = Item(
        nombre="Espada Vampírica",
        rareza="Raro",
        valor_base=150,
        tipo="Arma",
        stats={"daño": 12},
    )
    heroe = Player("Guerrero")
    heroe.equipar(espada_rara)  # Daño total = 5 (base) + 12 (espada) = 17

    # 2. Aparece un enemigo
    goblin = Enemy(
        nombre="Goblin Ladrón", hp=30, daño=3, exp_recompensa=10, oro_recompensa=5
    )
    print(f"\n👾 Un salvaje {goblin.nombre} ha aparecido con {goblin.hp_max} de vida.")

    # 3. Simulamos un turno de combate
    daño_del_heroe = heroe.obtener_daño_total()

    print(f"\n⚔️ {heroe.nombre} ataca con su {heroe.equipamiento['Arma'].nombre}!")

    # El héroe golpea al monstruo
    goblin.recibir_daño(daño_del_heroe)

    # Comprobamos el estado del monstruo
    if not goblin.esta_vivo():
        print(
            f"🏆 {goblin.nombre} ha sido derrotado. Ganas {goblin.oro_recompensa} de oro."
        )
    else:
        print(f"👹 {goblin.nombre} resistió el golpe y se prepara para contraatacar.")
