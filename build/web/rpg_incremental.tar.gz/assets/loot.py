import random

# Importamos tu molde de objetos de la Fase 1
from clases import Item

# 1. BASES: (Nombre, Valor Oro, Tipo, Stats Base)
ARMAS_BASE = [
    ("Espada Corta", 10, "Arma", {"daño": 5}),
    ("Hacha Pesada", 15, "Arma", {"daño": 8}),
    ("Daga Rápida", 8, "Arma", {"daño": 4, "critico": 5}),
]

# 2. PREFIJOS: Modificadores que van antes del nombre
PREFIJOS = [
    ("Vampírico/a", {"robo_vida": 5}),
    ("Brutal", {"daño": 10}),
    ("Veloz", {"velocidad": 10}),
]

# 3. SUFIJOS: Modificadores que van después del nombre
SUFIJOS = [
    ("del Oso", {"fuerza": 5, "hp_max": 20}),
    ("del Halcón", {"critico": 10}),
    ("del Rey", {"oro_extra": 15}),
]


def generar_arma_aleatoria():
    # A. Tirada de Rareza (Un dado del 1 al 100)
    tirada = random.randint(1, 100)

    rareza = "Común"
    cantidad_afijos = 0

    if tirada > 90:  # 10% de probabilidad de ser Raro
        rareza = "Raro"
        cantidad_afijos = 2
    elif tirada > 60:  # 30% de probabilidad de ser Mágico
        rareza = "Mágico"
        cantidad_afijos = 1

    # B. Elegir el arma base
    base_elegida = random.choice(ARMAS_BASE)
    nombre_final = base_elegida[0]
    valor_final = base_elegida[1]

    # Usamos .copy() para no modificar la plantilla original accidentalmente
    stats_finales = base_elegida[3].copy()

    # C. Aplicar Prefijo si corresponde
    if cantidad_afijos > 0:
        prefijo = random.choice(PREFIJOS)
        nombre_final = f"{prefijo[0]} {nombre_final}"
        # .update() fusiona los diccionarios, sumando los stats del prefijo
        stats_finales.update(prefijo[1])
        valor_final *= 2  # Un arma mágica vale el doble

    # D. Aplicar Sufijo si es Raro
    if cantidad_afijos > 1:
        sufijo = random.choice(SUFIJOS)
        nombre_final = f"{nombre_final} {sufijo[0]}"
        stats_finales.update(sufijo[1])
        valor_final *= 3  # Un arma rara vale aún más

    # E. Fabricar el objeto final usando tu clase Item
    return Item(
        nombre=nombre_final,
        rareza=rareza,
        valor_base=valor_final,
        tipo=base_elegida[2],
        stats=stats_finales,
    )


# --- ZONA DE PRUEBAS DEL GENERADOR ---
if __name__ == "__main__":
    print("🎲 GENERANDO 5 ARMAS ALEATORIAS 🎲\n")
    for i in range(5):
        nuevo_botin = generar_arma_aleatoria()
        print(nuevo_botin)
