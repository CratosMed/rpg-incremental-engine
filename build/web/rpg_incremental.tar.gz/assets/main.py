import pygame
import sys
import random
import asyncio


# Importamos las clases que construiste en la Fase 1
from clases import Player, Enemy, Item
from loot import generar_arma_aleatoria

pygame.init()

# Configuración de pantalla
WIDTH = 800
HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("RPG Incremental - Auto Battler")

# Colores y Fuentes
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (200, 50, 50)
GREEN = (50, 200, 50)
GOLD = (255, 215, 0)


# --- FUNCIÓN PARA DIBUJAR BARRAS DE VIDA ---
def dibujar_barra_vida(pantalla, x, y, hp_actual, hp_max, ancho=200, alto=25):
    # 1. Calculamos el porcentaje de vida (evitando que baje de 0)
    porcentaje = max(0, hp_actual / hp_max)
    ancho_actual = int(ancho * porcentaje)

    # 2. Dibujamos el fondo de la barra (Gris oscuro para la vida perdida)
    pygame.draw.rect(pantalla, (50, 50, 50), (x, y, ancho, alto))

    # 3. Dibujamos la barra llena (Verde o Roja dependiendo de quién sea)
    # Si la barra está en el lado izquierdo (Héroe) la pintamos verde, si no, roja.
    color = GREEN if x < 400 else RED
    pygame.draw.rect(pantalla, color, (x, y, ancho_actual, alto))

    # 4. Dibujamos un borde blanco alrededor para que se vea pulida
    pygame.draw.rect(pantalla, WHITE, (x, y, ancho, alto), 2)


font_grande = pygame.font.Font(None, 48)
font_normal = pygame.font.Font(None, 32)


# --- PREPARACIÓN DEL JUEGO ---
# 1. Creamos al Héroe y le damos un arma inicial
async def main():
    heroe = Player("Guerrero")
    espada_inicial = Item("Espada Oxidada", "Común", 5, "Arma", {"daño": 5})
    heroe.equipar(espada_inicial)

    # 2. Función para generar un nuevo monstruo cuando el anterior muera
    def generar_enemigo():
        return Enemy(
            nombre="Goblin Ladrón", hp=30, daño=3, exp_recompensa=10, oro_recompensa=5
        )

    enemigo_actual = generar_enemigo()

    # 3. Variables para controlar el tiempo de los ataques (Cooldowns)
    # 1000 milisegundos = 1 segundo
    cooldown_heroe = 1000
    cooldown_enemigo = 1500

    ultimo_ataque_heroe = 0
    ultimo_ataque_enemigo = 0

    mensaje_accion = "¡Inicia el combate!"
    mensaje_botin = ""

    # Bucle Principal
    clock = pygame.time.Clock()
    running = True
    in_inventory = False

    while running:
        # Tiempo actual en milisegundos
        tiempo_actual = pygame.time.get_ticks()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                # Abrir/Cerrar inventario
                if event.key == pygame.K_i:
                    in_inventory = not in_inventory

                # --- SISTEMA DE INVENTARIO: VENDER Y EQUIPAR ---
                elif (
                    in_inventory and event.key >= pygame.K_1 and event.key <= pygame.K_9
                ):

                    # Convertimos la tecla en el índice de la lista (0 a 8)
                    indice = event.key - pygame.K_1

                    if indice < len(heroe.inventario):

                        # Detectamos si el jugador está presionando la tecla SHIFT
                        mods = pygame.key.get_mods()

                        if mods & pygame.KMOD_SHIFT:
                            # --- MODO EQUIPAR (SHIFT + NÚMERO) ---
                            # 1. Sacamos el objeto de la mochila
                            nuevo_item = heroe.inventario.pop(indice)
                            tipo = nuevo_item.tipo  # Ej: "Arma"

                            # 2. Revisamos si ya hay algo en la mano del héroe
                            item_actual = heroe.equipamiento.get(tipo)

                            if item_actual is not None:
                                # Si tenía un arma, la devolvemos a la mochila para no perderla
                                heroe.inventario.append(item_actual)
                                print(
                                    f"🎒 Has guardado tu {item_actual.nombre} en la mochila."
                                )

                            # 3. Le ponemos la nueva arma en la mano
                            heroe.equipamiento[tipo] = nuevo_item
                            print(f"⚔️ ¡Te has equipado: {nuevo_item.nombre}!")

                        else:
                            # --- MODO VENDER (SOLO EL NÚMERO) ---
                            item_vendido = heroe.inventario.pop(indice)
                            heroe.oro += item_vendido.valor_base
                            print(
                                f"💰 Has vendido {item_vendido.nombre} por {item_vendido.valor_base} oro."
                            )
                # --- NUEVO: Sistema de Herrería (Presionar H) ---
                elif in_inventory and event.key == pygame.K_h:
                    arma_equipada = heroe.equipamiento["Arma"]

                    if arma_equipada:
                        # El costo aumenta progresivamente: 100, 150, 200...
                        costo_mejora = 100 + (arma_equipada.nivel_mejora * 50)

                        if heroe.oro >= costo_mejora:
                            heroe.oro -= costo_mejora

                            # Tiramos los dados de probabilidad (Ejemplo: 70% de éxito)
                            probabilidad = random.randint(1, 100)

                            if probabilidad <= 70:
                                arma_equipada.nivel_mejora += 1
                                # Aumentamos el daño base del arma un 20% con cada nivel
                                daño_actual = arma_equipada.stats.get("daño", 0)
                                arma_equipada.stats["daño"] = int(daño_actual * 1.2) + 2
                                print(
                                    f"🔨 ¡ÉXITO! Tu {arma_equipada.nombre} ha subido a +{arma_equipada.nivel_mejora}"
                                )
                            else:
                                print(
                                    f"💥 ¡CRAC! La mejora falló. Has perdido los {costo_mejora} de oro."
                                )
                        else:
                            print(
                                f"❌ No tienes oro suficiente. Cuesta {costo_mejora} y tienes {heroe.oro}."
                            )
                    else:
                        print("❌ No tienes ninguna arma equipada para mejorar.")

        # --- LÓGICA DE COMBATE AUTOMÁTICO ---
        if not in_inventory:
            # Si ha pasado suficiente tiempo, el héroe ataca
            if tiempo_actual - ultimo_ataque_heroe > cooldown_heroe:
                daño = heroe.obtener_daño_total()
                enemigo_actual.recibir_daño(daño)
                mensaje_accion = f"{heroe.nombre} ataca por {daño} de daño!"
                ultimo_ataque_heroe = (
                    tiempo_actual  # Reiniciamos el cronómetro del héroe
                )

                # Comprobamos si el enemigo murió tras el golpe
                if not enemigo_actual.esta_vivo():
                    heroe.oro += enemigo_actual.oro_recompensa
                    heroe.ganar_exp(enemigo_actual.exp_recompensa)

                    # --- NUEVO: Probabilidad de Drop (40%) ---
                    if random.randint(1, 100) <= 40:
                        nuevo_item = generar_arma_aleatoria()
                        heroe.inventario.append(
                            nuevo_item
                        )  # Lo guardamos en su mochila

                        # Le damos un color al texto según la rareza
                        if nuevo_item.rareza == "Raro":
                            mensaje_botin = f"¡BOTÍN ÉPICO!: {nuevo_item.nombre}"
                        elif nuevo_item.rareza == "Mágico":
                            mensaje_botin = f"Botín Mágico: {nuevo_item.nombre}"
                        else:
                            mensaje_botin = f"Botín: {nuevo_item.nombre}"

                    mensaje_accion = f"¡{enemigo_actual.nombre} derrotado! +{enemigo_actual.oro_recompensa} Oro"
                    enemigo_actual = generar_enemigo()
                    ultimo_ataque_enemigo = tiempo_actual

            # Si el enemigo sigue vivo y es su turno de atacar
            elif tiempo_actual - ultimo_ataque_enemigo > cooldown_enemigo:
                # El héroe recibe daño (por ahora restamos directo, luego usaremos una función)
                heroe.hp_actual -= enemigo_actual.daño
                mensaje_accion = (
                    f"{enemigo_actual.nombre} contraataca por {enemigo_actual.daño}!"
                )
                ultimo_ataque_enemigo = tiempo_actual

        # --- RENDERIZADO (DIBUJAR LA INTERFAZ) ---
        screen.fill(BLACK)

        # Textos del Héroe (Izquierda)
        texto_heroe = font_grande.render(
            f"{heroe.nombre} (Nv. {heroe.nivel})", True, WHITE
        )
        texto_oro = font_normal.render(f"Oro: {heroe.oro}", True, GOLD)
        texto_exp = font_normal.render(
            f"EXP: {heroe.exp_actual}/{heroe.exp_necesaria}", True, (100, 200, 255)
        )  # Azul clarito
        screen.blit(texto_exp, (50, 280))

        screen.blit(texto_heroe, (50, 150))
        # Llamamos a la función de la barra de vida para el héroe
        dibujar_barra_vida(screen, 50, 200, heroe.hp_actual, heroe.hp_max)
        screen.blit(texto_oro, (50, 240))

        # Textos del Enemigo (Derecha)
        texto_enemigo = font_grande.render(f"{enemigo_actual.nombre}", True, WHITE)

        screen.blit(texto_enemigo, (500, 150))
        # Llamamos a la función de la barra de vida para el enemigo
        dibujar_barra_vida(
            screen, 500, 200, enemigo_actual.hp_actual, enemigo_actual.hp_max
        )

        # Registro de Acción (Centro abajo)
        texto_accion = font_normal.render(mensaje_accion, True, WHITE)
        screen.blit(texto_accion, (WIDTH // 2 - texto_accion.get_width() // 2, 450))
        # --- NUEVO: Mostrar el último botín recogido ---
        if mensaje_botin:
            # Si es un botín Raro, lo pintamos de dorado, si no, blanco
            color_texto = GOLD if "ÉPICO" in mensaje_botin else WHITE
            texto_loot = font_normal.render(mensaje_botin, True, color_texto)
            screen.blit(texto_loot, (WIDTH // 2 - texto_loot.get_width() // 2, 500))

        # --- NUEVA INTERFAZ DE INVENTARIO ---
        if in_inventory:
            # 1. Crear un fondo semitransparente oscuro
            overlay = pygame.Surface((WIDTH, HEIGHT))
            overlay.set_alpha(220)  # Nivel de transparencia (0 a 255)
            overlay.fill(BLACK)
            screen.blit(overlay, (0, 0))

            # 2. Título de la pantalla
            titulo_inv = font_grande.render("MOCHILA DEL HÉROE", True, GOLD)
            screen.blit(titulo_inv, (WIDTH // 2 - titulo_inv.get_width() // 2, 50))

            # --- NUEVO: Instrucciones de uso ---
            instrucciones = font_normal.render(
                "Presiona [1-9] para Vender | [SHIFT] + [1-9] para Equipar",
                True,
                (150, 150, 150),
            )
            screen.blit(
                instrucciones, (WIDTH // 2 - instrucciones.get_width() // 2, 100)
            )

            # 3. Dibujar la lista de objetos recolectados (Este es tu código actual, solo ajusta el y_offset si queda muy pegado)
            y_offset = 150

            if len(heroe.inventario) == 0:
                texto_vacio = font_normal.render(
                    "El inventario está vacío.", True, (150, 150, 150)
                )
                screen.blit(texto_vacio, (100, y_offset))
            else:
                # Recorremos la mochila y mostramos cada objeto
                for i, item in enumerate(heroe.inventario):
                    # Le damos color según su rareza
                    color_item = (
                        GOLD
                        if item.rareza == "Raro"
                        else (100, 200, 255) if item.rareza == "Mágico" else WHITE
                    )

                    texto_item = font_normal.render(
                        f"{i + 1}. {item.nombre} ({item.valor_base} Oro)",
                        True,
                        color_item,
                    )
                    screen.blit(texto_item, (100, y_offset))

                    y_offset += 40  # Bajamos 40 píxeles para el siguiente objeto

                    # Límite visual: Mostramos solo los primeros 10 para que no se salgan de la pantalla por ahora
                    if i >= 9:
                        texto_mas = font_normal.render(
                            f"... y {len(heroe.inventario) - 10} objetos más ocultos.",
                            True,
                            (150, 150, 150),
                        )
                        screen.blit(texto_mas, (100, y_offset))
                        break

            # --- NUEVO: Interfaz de la Herrería (Lado Derecho) ---
            pygame.draw.rect(
                screen, (30, 30, 30), (450, 100, 300, 400)
            )  # Panel gris oscuro
            pygame.draw.rect(screen, WHITE, (450, 100, 300, 400), 2)  # Borde blanco

            titulo_herreria = font_normal.render("HERRERÍA", True, GOLD)
            screen.blit(titulo_herreria, (550, 120))

            arma = heroe.equipamiento["Arma"]
            if arma:
                texto_arma = font_normal.render(
                    f"Eq: {arma.nombre} (+{arma.nivel_mejora})", True, WHITE
                )
                daño_arma = font_normal.render(
                    f"Daño aportado: {arma.stats.get('daño', 0)}", True, GREEN
                )

                costo = 100 + (arma.nivel_mejora * 50)
                color_costo = GOLD if heroe.oro >= costo else RED
                texto_costo = font_normal.render(
                    f"Costo Mejora: {costo} Oro", True, color_costo
                )
                texto_boton = font_normal.render(
                    "Presiona [H] para mejorar", True, (150, 150, 150)
                )
                texto_prob = font_normal.render(
                    "Probabilidad de éxito: 70%", True, (100, 200, 255)
                )

                screen.blit(texto_arma, (470, 180))
                screen.blit(daño_arma, (470, 220))
                screen.blit(texto_costo, (470, 280))
                screen.blit(texto_prob, (470, 320))
                screen.blit(texto_boton, (470, 380))
            else:
                texto_sin_arma = font_normal.render("No hay arma equipada", True, RED)
                screen.blit(texto_sin_arma, (470, 200))
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()


# --- ARRANQUE DEL JUEGO ---
asyncio.run(main())
